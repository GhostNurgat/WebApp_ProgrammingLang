public static class HelloWorld
{
    public static string Hello() => "Hello, World!";
}
